﻿using System.Diagnostics;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Xstudio_Help_Assistant.Models;

namespace Xstudio_Help_Assistant.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public HomeController(ILogger<HomeController> logger, IWebHostEnvironment webHostEnvironment)
        {
            _logger = logger;
            _webHostEnvironment = webHostEnvironment;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> UploadFile(IEnumerable<IFormFile> files)
        {

            // Define upload directory inside wwwroot/uploads
            string uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "uploads");
            List<object> uploadResults = new List<object>();

            // Ensure directory exists
            if (!Directory.Exists(uploadsFolder))
            {
                Directory.CreateDirectory(uploadsFolder);
            }
            if (files != null && files.Count() > 0)
            {
                foreach (var file in files)
                {
                    Guid newGuid = Guid.NewGuid();

                    if (file != null && file.Length > 0)
                    {
                        // Get file extension
                        string[] allowedExtensions = { ".pdf", ".doc", ".docx" };
                        string fileExtension = Path.GetExtension(file.FileName).ToLower();

                        if (!allowedExtensions.Contains(fileExtension))
                        {
                            if (!allowedExtensions.Contains(fileExtension))
                            {
                                uploadResults.Add(new { fileName = file.FileName, status = "Invalid file type" });
                                continue;
                            }
                        }

                        string newFileName = $"{newGuid}_{file.FileName}";
                        string filePath = Path.Combine(uploadsFolder, newFileName);

                        try
                        {
                            using (var stream = new FileStream(filePath, FileMode.Create))
                            {
                                await file.CopyToAsync(stream);
                            }
                            uploadResults.Add(new { fileName = file.FileName, status = "Uploaded Successfully" });
                        }
                        catch (Exception ex)
                        {
                            uploadResults.Add(new { fileName = file.FileName, status = "Upload Failed: " + ex.Message });
                        }

                    }

                }
            }
            return Ok(uploadResults);

        }

        [HttpGet]
        public List<string> GetListOfFiles()
        {
            List<string> files = new List<string>();
            try
            {
                string uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "uploads");

                // Ensure directory exists
                if (Directory.Exists(uploadsFolder))
                {

                    Path.GetFileName(Directory.GetFiles(uploadsFolder)[0]);
                    var storeFiles = Directory.GetFiles(uploadsFolder);
                    foreach (var file in storeFiles)
                    {
                        var fileName = Path.GetFileName(file).Replace($"{Path.GetFileName(file).Split("_")[0]}_", "");
                        files.Add(fileName);

                    }

                }


            }
            catch (Exception)
            {

                throw;
            }

            return files;
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
