﻿
//** Js **/
const typingForm = document.querySelector(".typing-form");
const chatContainer = document.querySelector(".chat-list");
const suggestions = document.querySelectorAll(".suggestion");
const toggleThemeButton = document.querySelector("#theme-toggle-button");
const deleteChatButton = document.querySelector("#delete-chat-button");

// State variables
let userMessage = null;
let isResponseGenerating = false;

document.getElementsByClassName("typing-input")[0].addEventListener("keypress", function (event) {
    
    if (event.key === "Enter") {
        event.preventDefault();
        sendMessage($('.typing-input').val());
    }
});

function getListofFile() {
    try {
        
        $.ajax({
            url: "/Home/GetListOfFiles",
            type: "GET",
            success: function (response) {
                debugger;
                var html = ""
                for (const file of response) {
                    const listItem = document.createElement("li");

                    listItem.textContent = file;

                    fileList.appendChild(listItem);


                    html += `<option> ${file} </option>`;


                }
                $('#slcFiledropdwon').empty().html(html);
                $('#btnDelete,#slcFiledropdwon,#btnUpload').removeClass("d-none");

            },
            error: function (xhr, status, error) {

                console.error("Upload Error:", error);
            },
            complete: function () {
                console.log("Upload Complete");
            }
        });

    } catch (e) {
        console.log("getListofFile", e)
    }
}
getListofFile()

// Load theme and chat data from local storage on page load
const loadDataFromLocalstorage = () => {
    
    const defaultMessage = "Hello, I am your XStudio assistant! How can I help you today?";

    var html = `<div class="message incoming loading"> 
                    <div class="message-content" style="display: flex;justify-content: start;">
					  <p class="text-gemini" style="color:white;">${defaultMessage}</p>
					</div>
					<span onClick="copyMessage(this)" class="icon material-symbols-rounded">content_copy</span>
                </div>`;
    var savedChats = localStorage.getItem("saved-chats");
    const isLightMode = (localStorage.getItem("themeColor") === "light_mode");
    document.body.classList.toggle("light_mode", isLightMode);
    toggleThemeButton.innerText = isLightMode ? "dark_mode" : "light_mode";

    if (savedChats == null)
        savedChats = html

    chatContainer.innerHTML = savedChats || '';

    document.body.classList.toggle("hide-header", savedChats);
    chatContainer.scrollTo(0, chatContainer.scrollHeight); // Scroll to the bottom
}

//const loadDataFromLocalstorage = () => {
//    const savedChats = localStorage.getItem("saved-chats");

//    const isLightMode = (localStorage.getItem("themeColor") === "light_mode");
//    document.body.classList.toggle("light_mode", isLightMode);
//    toggleThemeButton.innerText = isLightMode ? "dark_mode" : "light_mode";

//    chatContainer.innerHTML = savedChats || '';

//    // If no chat history, append the default message
//    if (!savedChats) {
//        appendDefaultMessage();
//    }

//    document.body.classList.toggle("hide-header", savedChats);
//    chatContainer.scrollTo(0, chatContainer.scrollHeight); // Scroll to the bottom
//};

// Call the function to load data and display the default message
loadDataFromLocalstorage();

// Show typing effect by displaying words one by one
const showTypingEffect = (text, textElement, incomingMessageDiv) => {
    debugger
    const words = text.split(' ');
    let currentWordIndex = 0;
    const typingInterval = setInterval(() => {
        textElement.innerText += (currentWordIndex === 0 ? '' : ' ') + words[currentWordIndex++];
        incomingMessageDiv.querySelector(".icon").classList.add("hide");
        if (currentWordIndex === words.length) {
            clearInterval(typingInterval);
            isResponseGenerating = false;
            incomingMessageDiv.querySelector(".icon").classList.remove("hide");

            localStorage.setItem("saved-chats", chatContainer.innerHTML); // Save chats to local storage
        }
        chatContainer.scrollTo(0, chatContainer.scrollHeight);
    }, 75);
}

// Show a loading animation while waiting for the API response
const showLoadingAnimation = (response = "") => {
    $('.incoming-pre').hide()
    const html = `<div class="message-content" style="display: flex;justify-content: start;">
					  <p class="text-gemini" style="color:white;"></p>
					   <div class="loading-indicator">
							<div class="loading-bar"></div>
							<div class="loading-bar"></div>
							<div class="loading-bar"></div>
						</div>
					</div>
					<span onClick="copyMessage(this)" class="icon material-symbols-rounded">content_copy</span>`;
    const incomingMessageDiv = createMessageElement(html, "incoming", "loading");
    chatContainer.appendChild(incomingMessageDiv);
    chatContainer.scrollTo(0, chatContainer.scrollHeight); // Scroll to the bottom
    const textElement = incomingMessageDiv.querySelector(".text-gemini");

    if (response != "")
        showTypingEffect(response, textElement, incomingMessageDiv);
    setTimeout(function () { $('.loading-indicator').hide() }, 200)
}

// Copy message text to the clipboard
const copyMessage = (copyButton) => {
    const messageText = copyButton.parentElement.querySelector(".text").innerText;
    navigator.clipboard.writeText(messageText);
    copyButton.innerText = "done"; // Show confirmation icon
    setTimeout(() => copyButton.innerText = "content_copy", 1000); // Revert icon after 1 second
}

// Handle sending outgoing chat messages
const handleOutgoingChat = () => {
    userMessage = typingForm.querySelector(".typing-input").value.trim() || userMessage;
    if (!userMessage || isResponseGenerating) return; // Exit if there is no message or response is generating
    isResponseGenerating = true;

    const html = `<div class="message-content">
					  <img class="avatar" src="https://ts4.mm.bing.net/th?id=OIP.srNFFzORAaERcWvhwgPzVAHaHa&pid=15.1" alt="User avatar">
					  <p class="text"></p>
					</div>`;
    const outgoingMessageDiv = createMessageElement(html, "outgoing");
    outgoingMessageDiv.querySelector(".text").innerText = userMessage;
    chatContainer.appendChild(outgoingMessageDiv);

    typingForm.reset(); // Clear input field
    document.body.classList.add("hide-header");
    chatContainer.scrollTo(0, chatContainer.scrollHeight); // Scroll to the bottom
    setTimeout(showLoadingAnimation, 500); // Show loading animation after a delay
}

// Toggle between light and dark themes
toggleThemeButton.addEventListener("click", () => {
    const isLightMode = document.body.classList.toggle("light_mode");
    localStorage.setItem("themeColor", isLightMode ? "light_mode" : "dark_mode");
    toggleThemeButton.innerText = isLightMode ? "dark_mode" : "light_mode";
});

// Delete all chats from local storage when the button is clicked
deleteChatButton.addEventListener("click", () => {
    if (confirm("Are you sure you want to delete all the chats?")) {

    }

});

// Create a new message element and return it
const createMessageElement = (content, ...classes) => {
    const div = document.createElement("div");
    div.classList.add("message", ...classes);
    div.innerHTML = content;
    return div;
}

function sendMessage(userMessage) {
    try {
        debugger;

        if (!userMessage || isResponseGenerating) return; // Exit if there is no message or response is generating
        isResponseGenerating = true;

        const html2 = `<div class="message-content">
						<p class="text" style="background: #474747;color: #ffffff; height: auto;max-width: 500px; border-radius: 24px 4px 24px 24px;padding: 8px 14px 10px 17px;"></p>
					  </div>`;
        const outgoingMessageDiv = createMessageElement(html2, "outgoing");
        outgoingMessageDiv.querySelector(".text").innerText = userMessage;
        chatContainer.appendChild(outgoingMessageDiv);

        const html = `<div class="message-content-pre" style="margin-top: 1.5rem;">
						<div class="loading-indicator">
							  <div class="loading-bar"></div>
							  <div class="loading-bar"></div>
							  <div class="loading-bar"></div>
							</div>
					  </div>
					  <span onClick="copyMessage(this)" class="icon material-symbols-rounded">content_copy</span>`;
        const incomingMessageDiv = createMessageElement(html, "incoming-pre", "loading");
        chatContainer.appendChild(incomingMessageDiv);
        chatContainer.scrollTo(0, chatContainer.scrollHeight);

        typingForm.reset(); // Clear input field
        document.body.classList.add("hide-header");
        chatContainer.scrollTo(0, chatContainer.scrollHeight);

        //setTimeout(function () {
        $.ajax({
            url: "http://127.0.0.1:8000/query",
            type: "POST",
            data: JSON.stringify({ query: userMessage }),
            contentType: "application/json",
            success: function (response) {
                debugger;
                console.log(response)
                setTimeout(showLoadingAnimation(response.response), 500);

            },
            error: function (xhr, status, error) {
                debugger
                console.error("Upload Error:", error);
            },
            complete: function () {
                console.log("Upload Complete");
            }
        });
        // }, 200)


    } catch (e) {
        console.error("UploadeFile", e)
    }
}


document.getElementById("fileInput").addEventListener("change", function (event) {
    debugger;

    const fileList = document.getElementById("fileList");
    var html = ""
    for (const file of event.target.files) {
        const listItem = document.createElement("li");

        listItem.textContent = file.name;

        fileList.appendChild(listItem);


        html += `<option> ${file.name} </option>`;


    }
    $('#slcFiledropdwon').empty().html(html);
    $('#btnDelete,#slcFiledropdwon,#btnUpload').removeClass("d-none");
});

function UploadeFile() {
    try {

        var fileInput = $("#fileInput")[0].files[0];

        if (!fileInput) {
            $("#uploadStatus").text("Please select a file.");
            return;
        }

        $('.Upload').removeClass('d-none');

        var formData = new FormData($("#frmUploadFile")[0]);

        $.ajax({
            url: "/Home/UploadFile",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function (response) {

                $('.Upload').addClass('d-none');
                $('.Finish').removeClass('d-none');

            },
            error: function (xhr, status, error) {

                $('.Upload').addClass('d-none');
                $('.failed').removeClass('d-none');
                console.error("Upload Error:", error);
            },
            complete: function () {
                console.log("Upload Complete");
            }
        });

    } catch (e) {
        console.error("UploadeFile", e)
    }
}